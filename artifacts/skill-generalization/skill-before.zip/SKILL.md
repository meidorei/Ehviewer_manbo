---
name: organize-ehviewer-manga
description: Organize EhViewer DOWNLOADS records into multilingual manga series using deterministic high-recall candidate generation, primary-model semantic adjudication, author-bucket and global audits, an offline human review page, strict JSON validation, SQLite dry-run writeback, backups, and verified Android Debug-package replacement. Use when asked to sort, group, review, deduplicate, or safely reorder an EhViewer manga library or its eh.db database.
---

# Organize EhViewer Manga

Run a gated workflow: export safely, annotate the complete library in bounded multilingual discovery batches, generate candidates, let the primary model decide semantics, require human review, then validate and write only the confirmed order.

## Non-negotiable rules

- Work only on the package and database explicitly placed in scope. Default to `com.ehviewer.manbo.debug`; never substitute a release package.
- Use the primary agent/model for semantic decisions. Do not delegate to subagents unless the user explicitly requests parallel agents.
- Never use title similarity as an automatic merge verdict. Rules generate candidates only.
- Never send database binaries, device paths, tokens, cookies, or download paths to a model. Use GID and title metadata only.
- Full-library discovery batches contain only GID, original position, title, and Japanese title; discovery annotations create recall hints only and never merge records.
- Preserve every GID. Do not delete suspected duplicates; the user decides deletion separately.
- Stop after generating the review page. Continue writeback only after the user returns or explicitly confirms the exported order JSON.
- Before device replacement, require matching fingerprints, a computer backup, a phone backup, a successful SQLite dry run, exact `TIME DESC` order, and `PRAGMA integrity_check = ok`.
- Reorder with the current write time for the first confirmed GID and exactly one-second descending steps for later GIDs. This creates a recent ordering block so future downloads sort above it.
- Stop on any permission, fingerprint, count, uniqueness, order, integrity, or hash mismatch. Never fall back to root.

## Read the detailed workflow

Read [references/workflow.md](references/workflow.md) before starting a new library run. It defines full-library discovery, the semantic-review rounds, JSON contracts, review-page requirements, cleanup gates, and recovery behavior.

Read [references/prompts.md](references/prompts.md) immediately before full-library discovery and the semantic-review rounds. Use its schemas and constraints, replacing placeholders only with the current run's safe metadata.

## Workflow

1. Confirm the ADB executable, device serial, target package, and an empty artifact directory.
2. Force-stop the target package and export `databases/eh.db` with `scripts/adb_transfer.py export`. This script uses `run-as ... cat` so binary output is not contaminated by transfer statistics.
3. Run `scripts/snapshot_catalog.py` to check SQLite integrity and create `llm-full-catalog.json` plus `snapshot-summary.json`.
4. Run `scripts/build_discovery_batches.py` with the default batch size of 75. It creates safe full-library discovery batches and a `run-manifest.json`; register each later generated artifact with `scripts/run_manifest.py register` as either `temporary` or `preserve`.
5. Perform one primary-model discovery response per batch, then run `scripts/validate_discovery.py`. It requires exactly one compact annotation per GID and produces complete `discovery-annotations.json`.
6. Run `scripts/generate_candidates.py --discovery ... --unresolved ...` to create overlapping high-recall candidates, complete author buckets, low-confidence collision audits, and the all-singleton unresolved index.
7. Perform four primary-model rounds: candidate adjudication, author-bucket missing-member audit, unresolved-index cross-language audit, and global series-index conflict audit. The global index must include unresolved singleton summaries and collision audits.
8. Merge decisions into one full version-2 decision file, then run `scripts/build_order.py`. Keep each series block at its earliest original member, preserve unrelated blocks' relative order, and display reliable members from newest to oldest by descending semantic `itemOrder`. Preserve original relative order for tied or unknown member positions.
9. Run `scripts/validate_order.py` against the model JSON.
10. Generate a self-contained offline page with `scripts/generate_review_page.py`. Confirm that every title and GID is present statically in the HTML, then hand the page to the user and stop.
11. When the user returns the exported JSON, run `scripts/validate_order.py` again, now with `--model` to ensure semantic fields were not silently modified.
12. Run `scripts/apply_order.py` against a newly exported phone database. It creates a backup and sorted copy, assigns the first confirmed GID the current write time and later GIDs one-second descending steps, and rejects any non-`TIME` change.
13. Create and hash a phone-side backup, upload the sorted copy to app cache with `scripts/adb_transfer.py upload`, then perform the same-filesystem replacement with `run-as` only.
14. Re-export before launch and after one successful app launch. Validate both exports against the confirmed JSON, register the two passed reports with `scripts/run_manifest.py verify`, and retain all backups.
15. Only after explicit user confirmation, run `scripts/cleanup_run.py` once for a preview and again with `--confirm`. It deletes only manifest-registered temporary artifacts and preserves final JSON, reports, and backups.

## Bundled scripts

- `snapshot_catalog.py`: read-only SQLite inspection, catalog export, GID fingerprint, and database hash.
- `build_discovery_batches.py`: default-75 safe metadata batches plus a cleanup-aware run manifest.
- `validate_discovery.py`: strict batch-result coverage and compact annotation validation, then complete annotation export.
- `generate_candidates.py`: deterministic candidates enhanced by discovery aliases and semantic keys, plus author buckets, collision audits, and unresolved indexes.
- `seed_historical_decisions.py`: optional review-only helper that reuses a prior decision only when the current GID's title metadata is unchanged; its inspected candidate overrides are always low-confidence and still require the normal review page.
- `run_manifest.py`: register generated artifacts and record passed pre-launch and post-launch reports.
- `cleanup_run.py`: verified preview or explicit cleanup of manifest-registered temporary artifacts.
- `build_order.py`: turn one full set of semantic decisions into stable `seriesOrder` and `gidOrder` arrays while keeping original series anchors and showing members newest-first.
- `validate_order.py`: strict JSON, fingerprint, GID, numeric-field, series-contiguity, and optional semantic-field validation.
- `generate_review_page.py`: static offline review page with search, collapsible series, series/internal drag, single-item pinning, restore, and JSON export.
- `apply_order.py`: backup plus transactional dry-run assignment of a current-time descending-second `DOWNLOADS.TIME` sequence; verifies exact order, integrity, unique timestamps, and preservation of all other fields.
- `adb_transfer.py`: exact `run-as` export and hash-checked upload to app cache. It intentionally does not perform replacement.

Run every script with `--help` before first use. Keep all outputs in one per-run artifact directory, never inside the Android repository unless the user explicitly asks.

## Human-review behavior

Treat pinned items as reordered items, not deletions. Export a complete GID order even when the user plans to delete duplicates later. If the user deletes records on the phone, export a new snapshot before any further writeback because the previous fingerprint is invalid.

## Artifact retention

Register every generated file in `run-manifest.json` immediately after it is created. Discovery batches, model discovery responses, merged discovery annotations, candidates, audit inputs, unresolved indexes, and review HTML are `temporary`. Final confirmed order JSON, verification reports, source snapshots, and computer or phone backups are `preserve`.

Never clean a run automatically. After the user explicitly confirms cleanup and the manifest records hash-checked `status: passed` reports from both pre-launch and post-launch validation, preview cleanup first. A confirmed cleanup never removes a preserved artifact.

## Completion report

Report the item count, series count, low-confidence series count, snapshot fingerprint, final JSON hash, backup locations and hashes, dry-run status, pre-launch verification, post-launch verification, and any limitation in visual inspection.
