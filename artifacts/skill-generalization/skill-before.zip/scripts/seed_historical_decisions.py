#!/usr/bin/env python3
"""Build a review-only decision draft from an unchanged earlier catalog.

This helper deliberately never writes a database or produces a confirmed order.
It can reuse semantic rows only when the GID's current title metadata is byte-for-
byte unchanged from the explicitly supplied historical catalog.  Newly appeared
items remain singleton records unless they are in the small, auditable set of
high-recall candidates below; every such merge is marked for human review.
"""

import argparse
import json
from pathlib import Path


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def title_for(item):
    return item.get("title") or item.get("titleJpn") or f"GID {item['gid']}"


def semantic(gid, series_id, series_title, branch, item_order, confidence, reason):
    return {
        "gid": int(gid),
        "canonicalSeriesId": series_id,
        "canonicalSeriesTitle": series_title,
        "branch": branch,
        "itemOrder": item_order,
        "confidence": confidence,
        "reason": reason,
    }


def review_overrides(decisions):
    """Apply only manually inspected current candidates, all below 0.85 confidence."""
    groups = (
        ("immortal-head-deep-desire-nostalgia", "Deep Desire Nostalgia", 0.70,
         "同作者同名及明确 II 标记；两条 joke ver. 疑似重复翻译，需人工确认。",
         ((4113848, "translation", 1), (4115851, "translation", 1), (4122265, "main", 2))),
        ("dongli-mom-stocking-footjob", "妈妈是丝袜足交技师", 0.70,
         "同标题的 01-10 完整集与 06-10 子集，疑似重叠合集，需人工确认。",
         ((4111786, "collection", 1), (4119979, "collection", 1))),
        ("ijiise-overseas-newlywed-wife", "海外出身の新婚妻が他の男とヤリたいと土下座してきました", 0.78,
         "中篇标题和日文标题一致；新增条目疑似同一中篇的另一翻译。",
         ((3361881, "main", 1), (3395464, "main", 2), (4114882, "translation", 2))),
        ("jikahatsudensho-juu-monogatari", "十物語", 0.78,
         "标题、作者、日文标题完全一致；疑似重复下载记录。",
         ((4105527, "translation", 1), (4116993, "translation", 1))),
        ("takeda-chadou-yamato-nadeshiko-ntr", "茶道大和撫子NTR", 0.78,
         "标题、作者、日文标题完全一致；疑似重复下载记录。",
         ((4088729, "translation", 1), (4113076, "translation", 1))),
        ("lrb4-rimworld-alien-custom-guide", "Rimworld-边缘世界异种风俗指南", 0.78,
         "标题和作者完全一致；疑似重复下载记录。",
         ((4079752, "translation", 1), (4114680, "translation", 1))),
        ("urakan-kyouko", "絡まれ妻の今日子さん", 0.78,
         "同作者同名的 1~9 与 1~10 合集，以及同名章节；合集和章节关系需人工确认。",
         ((3790410, "collection", 1), (4114523, "collection", 1), (2287088, "main", 20), (2354849, "main", 30))),
        ("senaka-musuko-sex", "息子のおかげで、セックスが大好きになれました。", 0.78,
         "同作者同标题，数字 1 与 2 连续，需人工确认是否为正式续篇。",
         ((3865049, "main", 1), (4114909, "main", 2))),
        ("ronna-ai-hospital", "麦晓雯人工智能病院", 0.70,
         "同作者同副标题，上、下集明确对应，但 EP 编号不连续，需人工确认。",
         ((4114661, "main", 47), (4114673, "main", 49))),
        ("tuna-empire-houkago-dorei-club", "放課後奴隷倶楽部", 0.84,
         "同作者或作者别名、同主标题，含第 2 节课和新入部员篇，需人工确认完整顺序。",
         ((73741, "main", 1), (780959, "main", 2), (4111058, "extra", 3))),
        ("hotate-deriheru-ex-girlfriend-mom", "デリヘル呼んだら別れた彼女のママが来た", 0.78,
         "作者、罗马音主标题与中文译名一致；疑似重复下载记录。",
         ((4117350, "translation", 1), (4123673, "translation", 1))),
        ("ani-ga-saru-low-height", "ナニをしても許される低身長デカパイ男性がいる世界", 0.78,
         "标题、作者和日文标题完全一致；疑似重复下载记录。",
         ((4116746, "translation", 1), (4118973, "translation", 1))),
    )
    known = set(decisions)
    for series_id, series_title, confidence, reason, rows in groups:
        missing = [gid for gid, _branch, _order in rows if gid not in known]
        if missing:
            raise RuntimeError(f"review override has absent GIDs: {missing}")
        for gid, branch, item_order in rows:
            decisions[gid] = semantic(gid, series_id, series_title, branch, item_order, confidence, reason)


def build(current, history_catalog, history_decisions):
    if history_decisions.get("formatVersion") != 2:
        raise RuntimeError("historical decision formatVersion must equal 2")
    current_items = {int(item["gid"]): item for item in current.get("items", [])}
    old_items = {int(item["gid"]): item for item in history_catalog.get("items", [])}
    old_decisions = {int(row["gid"]): row for row in history_decisions.get("decisions", [])}
    if len(old_decisions) != len(history_decisions.get("decisions", [])):
        raise RuntimeError("historical decisions contain duplicate GIDs")

    decisions = {}
    reused = changed = new = 0
    for gid, item in current_items.items():
        old_item = old_items.get(gid)
        old_row = old_decisions.get(gid)
        unchanged = old_item and old_row and (
            old_item.get("title") == item.get("title")
            and old_item.get("titleJpn") == item.get("titleJpn")
        )
        if unchanged:
            decisions[gid] = semantic(
                gid,
                old_row["canonicalSeriesId"],
                old_row["canonicalSeriesTitle"],
                old_row.get("branch", "main"),
                old_row["itemOrder"],
                old_row["confidence"],
                old_row["reason"],
            )
            reused += 1
        else:
            reason = "当前目录中新增记录；未发现可安全确认的系列关系，保留独立并待人工校对。"
            if old_item:
                reason = "标题元数据与历史快照不一致；不复用历史结论，保留独立并待人工校对。"
                changed += 1
            else:
                new += 1
            decisions[gid] = semantic(gid, f"item:{gid}", title_for(item), "main", 1, 0.0, reason)

    review_overrides(decisions)
    return {
        "formatVersion": 2,
        "snapshotFingerprint": current["snapshotFingerprint"],
        "status": "historical-seeded-pending-human-review",
        "historyReuse": {
            "reusedUnchangedGids": reused,
            "changedMetadataGids": changed,
            "newGids": new,
            "overrideGroups": 12,
            "note": "Historical rows are candidate seeds only; every override is low-confidence and requires human review.",
        },
        "decisions": [decisions[int(item["gid"])] for item in current["items"]],
    }


def main():
    parser = argparse.ArgumentParser(description="Create a review-only current decision draft from an unchanged historical catalog.")
    parser.add_argument("--catalog", required=True, type=Path)
    parser.add_argument("--history-catalog", required=True, type=Path)
    parser.add_argument("--history-decisions", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")
    output = build(read_json(args.catalog), read_json(args.history_catalog), read_json(args.history_decisions))
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"itemCount": len(output["decisions"]), **output["historyReuse"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
