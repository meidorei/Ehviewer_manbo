#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path


def strict_json(path):
    raw = path.read_text(encoding="utf-8").strip()
    value, end = json.JSONDecoder().raw_decode(raw)
    if raw[end:].strip():
        raise ValueError(f"{path} contains non-JSON suffix text")
    return value


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_artifact(root, relative):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise RuntimeError("manifest contains an invalid artifact path")
    path = (root / relative).resolve()
    try:
        path.relative_to(root)
    except ValueError as error:
        raise RuntimeError("artifact path escapes the run directory") from error
    return path


def load_verified_manifest(path):
    manifest = strict_json(path)
    if manifest.get("formatVersion") != 1 or manifest.get("kind") != "ehviewer-discovery-run":
        raise RuntimeError("invalid discovery run manifest")
    verification = manifest.get("verification")
    if not isinstance(verification, dict) or set(verification) != {"preLaunch", "postLaunch"}:
        raise RuntimeError("run has not completed pre-launch and post-launch verification")
    root = path.parent
    for name, entry in verification.items():
        if not isinstance(entry, dict):
            raise RuntimeError(f"{name} verification entry is invalid")
        report_path = resolve_artifact(root, entry.get("path"))
        if not report_path.is_file() or sha256_file(report_path) != entry.get("sha256"):
            raise RuntimeError(f"{name} verification report is missing or changed")
        if strict_json(report_path).get("status") != "passed":
            raise RuntimeError(f"{name} verification report is not passed")
    return manifest


def main():
    parser = argparse.ArgumentParser(description="Preview or confirm cleanup of temporary artifacts after verified EhViewer database replacement.")
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--confirm", action="store_true", help="Delete the previewed temporary artifacts after explicit user confirmation.")
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    manifest = load_verified_manifest(manifest_path)
    root = manifest_path.parent
    temporary = []
    for entry in manifest.get("artifacts", []):
        if not isinstance(entry, dict) or entry.get("retention") not in {"temporary", "preserve"}:
            raise RuntimeError("manifest has an invalid artifact retention entry")
        if entry["retention"] == "temporary":
            path = resolve_artifact(root, entry.get("path"))
            if not path.is_file():
                raise RuntimeError(f"temporary artifact is missing: {entry.get('path')}")
            temporary.append(path)
    result = {"status": "deleted" if args.confirm else "preview", "temporaryArtifacts": [path.relative_to(root).as_posix() for path in temporary]}
    if args.confirm:
        for path in temporary:
            path.unlink()
        manifest["cleanup"] = {"state": "complete", "deletedTemporaryArtifacts": result["temporaryArtifacts"]}
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
