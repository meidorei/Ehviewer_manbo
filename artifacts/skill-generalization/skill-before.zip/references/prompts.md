# Primary-model prompt contracts

Use only safe metadata from the current catalog. Do not include filesystem paths, database bytes, cookies, tokens, or unrelated device information. Require strict JSON without explanatory prose or Markdown fences.

## Full-library multilingual discovery

Provide one batch of at most 75 records, each containing only `gid`, `originalPosition`, `title`, and `titleJpn`. Instruct the primary model to annotate every supplied GID independently for recall generation; it must not declare that two records belong to the same final series.

Require compact, conservative output. Keep uncertain aliases empty rather than guessing. Use author aliases only as hints, preserve original titles in the input, and never include paths, database bytes, account data, or web-fetched metadata.

Response schema:

```json
{
  "formatVersion": 1,
  "snapshotFingerprint": "<input fingerprint>",
  "batchId": "discovery:00001",
  "annotations": [
    {
      "gid": 100001,
      "authorAliases": ["<at most 3 aliases>"],
      "workAliases": ["<at most 5 Japanese, Chinese, English, or romanized aliases>"],
      "semanticTitleKey": "<compact English meaning, or null>",
      "partKind": "unknown|chapter|episode|volume|part|collection|extra|remaster",
      "partNumber": "<optional compact number, or null>",
      "confidence": 0.8,
      "needsHumanReview": true
    }
  ]
}
```

Every input GID must appear exactly once, and annotations may not add fields beyond this schema.

## Candidate adjudication

Instruct the primary model to act as a multilingual manga cataloger and to treat candidates as high-recall proposals that may over-group, under-group, or overlap.

Require it to:

1. Assign a canonical series ID and title to every supplied GID.
2. Merge cross-script author aliases only when title meaning also supports the relationship.
3. Recognize chapters, episodes, volumes, parts, ranges, upper/middle/lower, front/back, collections, extras, remasters, and branches.
4. Keep overlapping collection and single-chapter downloads as separate records.
5. Preserve original relative order when reliable series order is unavailable.
6. Reject false candidates and keep uncertain items independent.
7. Return confidence in `[0,1]` and a short semantic reason.

Response schema:

```json
{
  "formatVersion": 2,
  "candidateId": "<input candidate id>",
  "decisions": [
    {
      "gid": 100001,
      "canonicalSeriesId": "series:placeholder",
      "canonicalSeriesTitle": "<canonical title>",
      "branch": "main",
      "itemOrder": 1,
      "confidence": 0.95,
      "reason": "<short reason>"
    }
  ],
  "possibleExternalAliases": []
}
```

## Author-bucket missing-member audit

Provide full author buckets plus already accepted series memberships. Ask the primary model to return only supported additions, splits, alias links, and rejected false positives. Emphasize translated titles, cross-script author names, shortened sequel titles, extras, collections, and remasters. Do not allow author identity alone to create a series.

## Global series-index audit

Provide compressed multi-item series cards, unresolved singleton summaries, and low-confidence collision audits. Include original titles for all low-confidence, cross-script, collection-range, extra, and remaster cases. Ask the primary model to detect duplicate canonical IDs, aliases split between batches, conflicting branch placement, missing members, and contradictory order.

## Unresolved-index audit

Provide the unresolved index generated from entries that did not enter any candidate component. Ask for only supported candidate additions based on cross-script author aliases, translated titles, romanization, compatible part signals, and semantic-title keys. Do not treat an alias or semantic key as a merge verdict by itself.

## Full-decision handoff

After resolving all three rounds, create one decision object for every catalog GID. Use a unique `item:<gid>` canonical ID for independent items. Do not omit rejected candidates; represent them as independent decisions. Pass the full decision file through `build_order.py` and `validate_order.py` before generating the human review page.
