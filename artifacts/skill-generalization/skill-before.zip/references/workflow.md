# EhViewer manga organization workflow

## Contents

1. Scope and artifacts
2. Snapshot contract
3. Full-library multilingual discovery
4. Candidate generation and unresolved index
5. Four semantic-review rounds
6. Final decision contract
7. Human review page
8. Validation, writeback, and cleanup
9. Device replacement and recovery

## 1. Scope and artifacts

Operate on the explicitly selected Debug package and its `DOWNLOADS` table. The list order is `TIME DESC`; do not assume a separate ordering column.

Keep one artifact directory per run containing the phone snapshot, title catalog, discovery batches and results, candidates, model decisions, global index, review page, human-exported order, original backup, sorted copy, verification reports, and `run-manifest.json`.

The run manifest is the only source of cleanup targets. Register every generated artifact immediately after creation. Discovery batches and all model-review intermediates are temporary; final order JSON, verification reports, snapshots, and backups are preserved.

## 2. Snapshot contract

Read the source database in SQLite read-only mode and require `PRAGMA integrity_check = ok`. Query metadata in `TIME DESC, GID DESC` order. Compute the snapshot fingerprint as SHA-256 of sorted decimal GIDs joined by newline.

Catalog schema:

```json
{
  "formatVersion": 2,
  "snapshotFingerprint": "<64 lowercase hex characters>",
  "items": [
    {
      "gid": 100001,
      "originalPosition": 1,
      "title": "<original title>",
      "titleJpn": "<optional alternate title>",
      "label": null,
      "state": 0
    }
  ]
}
```

Do not replace original titles with normalized forms. Derived author, skeleton, token, sequence, range, and part fields are additions only.

## 3. Full-library multilingual discovery

Run `build_discovery_batches.py` with its default size of 75. A 3184-item catalog therefore produces 43 batches. Each batch contains only `gid`, `originalPosition`, `title`, and `titleJpn`; never add labels, database paths, cookies, or binary data.

The primary model returns one version-1 discovery annotation per supplied GID. An annotation has at most three author aliases, five cross-language work aliases, one compact English semantic-title key, one part kind and optional number, confidence, and a human-review flag. It must identify recall hints only; it must not decide or claim a final series merge.

Run `validate_discovery.py` before candidate generation. It rejects missing or duplicate GIDs, batch or fingerprint mismatch, Markdown, extra text, oversized fields, invalid part kinds, and invalid confidence. The validated output is one complete discovery annotation file covering the entire catalog.

## 4. Candidate generation

Generate an overlapping union from same-author title skeletons, explicit sequence markers, nearby distinctive tokens, discovery aliases, semantic-title keys, and complete author buckets. Discovery-derived matches are candidate evidence only.

When a discovery alias or semantic-title key appears in more than 40 records, emit a low-confidence collision audit instead of connecting those records into one candidate component. Emit every remaining singleton with indexes for discovery author aliases, semantic-title keys, language signatures, and part signals. These unresolved entries must be included in later audits.

Program rules may propose candidates but may not produce semantic merge conclusions.

## 5. Four semantic-review rounds

### Round 1: candidate adjudication

Use the primary model to accept, reject, split, extend, or merge overlapping candidates. Require strict JSON without Markdown. Judge author identity and title meaning together; never merge solely because the author matches.

Recognize numbered chapters, ranges, upper/middle/lower, front/back parts, collections, extras, remasters, and parallel branches. Collections remain as downloaded items even when they overlap individual chapters.

When uncertain, keep an item independent and lower confidence.

### Round 2: author-bucket audit

Review complete author buckets for missing members, cross-script aliases, translated titles, shortened sequel titles, extras, collections, and remasters. This round is mandatory even when the first round appears complete.

### Round 3: unresolved-index audit

Review unresolved singleton indexes for cross-script author aliases, translated or shortened titles, romanization variants, compatible part signals, and aliases that were separated by batching. Keep unsupported items independent and mark uncertain connections for human review.

### Round 4: global series-index audit

Compress all multi-item series, unresolved singleton summaries, and collision audits into a global index. Review duplicate canonical IDs, aliases split across batches, contradictory ordering, cross-script merges, collection-range conflicts, remaster branches, and every series below confidence `0.85` with original titles attached.

## 6. Final decision contract

```json
{
  "formatVersion": 2,
  "snapshotFingerprint": "<same fingerprint>",
  "decisions": [
    {
      "gid": 100001,
      "canonicalSeriesId": "series:placeholder",
      "canonicalSeriesTitle": "<canonical title>",
      "branch": "main",
      "itemOrder": 1,
      "confidence": 0.95,
      "reason": "<short semantic reason>"
    }
  ],
  "seriesOrder": ["series:placeholder"],
  "gidOrder": [100001]
}
```

Anchor each series block at the position of its earliest original member in the source `TIME DESC` list. Order blocks by those anchors so unrelated series and standalone items keep their original relative order. Within a multi-item series, treat semantic `itemOrder` as old-to-new numbering but emit reliable members in descending `itemOrder`, newest to oldest, because EhViewer displays the resulting list in `TIME DESC`. Keep tied and unknown member positions stable in their original relative order. Preserve every download, including duplicate translations and overlapping collections.

## 7. Human review page

Write every title and GID directly into the HTML. Runtime JavaScript may enhance the page but must not be required to load the catalog.

Provide search, collapsible series, indented children, confidence and reasons, whole-series and within-series drag, low-confidence expansion, single-item pinning without moving the entire series, restoration, and complete JSON export with the unchanged fingerprint. Explain that the initial page keeps each series at its earliest source anchor and displays series members newest to oldest; restoration must return to that generated order.

Pinned items change order only. They are not deletion instructions.

## 8. Validation, writeback, and cleanup

Reject Markdown fences, non-JSON prefix/suffix, wrong format version, fingerprint mismatch, missing/extra/duplicate GIDs, decision/order mismatch, invalid numeric fields, or changed semantic fields in a human export. Model output should keep each series contiguous; a human export may intentionally split a series when a single member is pinned for duplicate review.

Before touching the device, export a fresh database and recheck its fingerprint. Create a computer backup and sorted copy. Immediately before the write transaction, take the current millisecond time for the first requested GID and subtract exactly one second for each later GID. Require one updated row per GID, exact `TIME DESC` order, unique `TIME`, integrity `ok`, and equality of every non-`TIME` field digest. A later download receives a newer app timestamp and therefore sorts above this generated block.

After the pre-launch and post-launch exports both validate successfully, register their passed reports with `run_manifest.py verify`. Do not run cleanup until the user explicitly confirms it. `cleanup_run.py` first previews the exact temporary files recorded in the run manifest; `--confirm` is allowed only after both report hashes and `status: passed` values still match. It never deletes preserved final JSON, reports, snapshots, or backups.

## 9. Device replacement and recovery

Force-stop the target package. Create phone-side and computer backups and compare hashes. Upload the verified sorted database to app cache and compare SHA-256. Inspect for live WAL or hot journal files before replacement.

Replace only within the app-owned filesystem through `run-as`. Keep the phone backup. Re-export and validate immediately, then repeat after one successful Debug-package launch.

If any step fails, stop. Do not delete the original or backup, do not use root, and do not try a release package.
