#!/usr/bin/env python3
"""Direct EhViewer grouping and safe copy-only ordering. Python standard library."""
import argparse
from contextlib import contextmanager, closing
import base64
import hashlib
import html
import json
import math
from pathlib import Path
import sqlite3
import time

KINDS = ('main', 'extra', 'collection', 'remaster', 'other')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pairs(values):
    out = {}
    for k, v in values:
        require(k not in out, 'duplicate JSON key: ' + k)
        out[k] = v
    return out


def read(path):
    def bad(value):
        raise ValueError('non-finite JSON: ' + value)
    return json.loads(Path(path).read_text('utf-8-sig'), object_pairs_hook=pairs, parse_constant=bad)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def integer(x):
    return type(x) is int and 0 < x <= 9007199254740991


def number(x):
    return type(x) in (int, float) and math.isfinite(x) and x >= 0


def normalize(value):
    values = value if isinstance(value, list) else value['items']
    require(isinstance(values, list), 'items must be a list')
    result = []
    for i, row in enumerate(values, 1):
        require(isinstance(row, dict) and integer(row.get('gid')), 'invalid GID')
        item = dict(gid=row['gid'], title=row.get('title'), titleJpn=row.get('titleJpn'), originalPosition=row.get('originalPosition', i))
        require(integer(item['originalPosition']), 'invalid originalPosition')
        require(all(x is None or isinstance(x, str) for x in (item['title'], item['titleJpn'])), 'invalid title')
        result.append(item)
    require(len({x['gid'] for x in result}) == len(result), 'duplicate GID')
    require(len({x['originalPosition'] for x in result}) == len(result), 'duplicate originalPosition')
    return sorted(result, key=lambda x: x['originalPosition'])


def catalog_hash(items):
    values = [{k: x[k] for k in ('gid', 'title', 'titleJpn')} for x in sorted(items, key=lambda x: x['gid'])]
    return hashlib.sha256(canonical(values).encode()).hexdigest()


def quote(name):
    return '"' + name.replace('"', '""') + '"'


@contextmanager
def connect(path):
    con = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    try:
        yield con
    finally:
        con.close()


def snapshot(source, target):
    target = Path(target)
    require(not target.exists(), 'refusing to overwrite snapshot: ' + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    with connect(source) as src, closing(sqlite3.connect(target)) as dst:
        src.backup(dst)
        require(dst.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'invalid SQLite snapshot')


def db_items(db, writable=False):
    with connect(db) as con:
        columns = {x[1].upper(): x[1] for x in con.execute('PRAGMA table_info(DOWNLOADS)')}
        require('GID' in columns and ('TITLE' in columns or 'TITLE_JPN' in columns), 'unsupported DOWNLOADS schema')
        if writable:
            require('TIME' in columns, 'DOWNLOADS.TIME missing')
            require(con.execute('SELECT count(*) FROM DOWNLOADS WHERE typeof(TIME) != \'integer\'').fetchone()[0] == 0, 'TIME must contain integer milliseconds')
        names = [quote(columns[k]) if k in columns else 'NULL' for k in ('GID', 'TITLE', 'TITLE_JPN')]
        order = 'TIME DESC, GID DESC' if 'TIME' in columns else 'GID DESC'
        values = con.execute('SELECT ' + ','.join(names) + ' FROM DOWNLOADS ORDER BY ' + order).fetchall()
    return normalize([dict(gid=g, title=t, titleJpn=j) for g, t, j in values])


def db_digest(db, ignore_time=False):
    def cell(value):
        return {'bytes': base64.b64encode(value).decode()} if isinstance(value, bytes) else value
    with connect(db) as con:
        schema = con.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
        all_data = []
        for table, in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            columns = [x[1] for x in con.execute('PRAGMA table_xinfo(' + quote(table) + ')') if x[6] != 1]
            kept = [c for c in columns if not (ignore_time and table.upper() == 'DOWNLOADS' and c.upper() == 'TIME')]
            rows = [canonical([cell(v) for v in row]) for row in con.execute('SELECT ' + ','.join(map(quote, kept)) + ' FROM ' + quote(table))]
            all_data.append([table, kept, sorted(rows)])
        value = [schema, con.execute('PRAGMA user_version').fetchone(), con.execute('PRAGMA application_id').fetchone(), all_data]
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def validate_plan(catalog, plan, confirmed=False):
    items = normalize(catalog)
    original = {x['gid']: x for x in items}
    require(type(plan.get('formatVersion')) is int and plan['formatVersion'] == 1, 'unsupported plan version')
    require(plan.get('catalogHash') == catalog_hash(items), 'library titles or GIDs changed')
    rows = plan.get('items')
    require(isinstance(rows, list), 'missing plan items')
    require(all(isinstance(r, dict) and integer(r.get('gid')) for r in rows), 'invalid plan GID')
    require(len(rows) == len(original) and {r['gid'] for r in rows} == set(original), 'plan must retain every GID exactly once')
    require(isinstance(plan.get('gidOrder'), list) and all(integer(g) for g in plan['gidOrder']) and plan['gidOrder'] == [r['gid'] for r in rows], 'order does not match items')
    names = {}
    for row in rows:
        require(all(row.get(k) == original[row['gid']][k] for k in ('title', 'titleJpn')), 'original title changed')
        for field in ('seriesId', 'series', 'branch'):
            require(isinstance(row.get(field), str) and row[field].strip(), 'invalid ' + field)
        require(names.get(row['seriesId'], row['series']) == row['series'], 'inconsistent series name')
        names[row['seriesId']] = row['series']
        require(row.get('category') in KINDS, 'invalid category')
        require(row.get('order') is None or number(row['order']), 'invalid chapter order')
        require(row.get('end') is None or (number(row['end']) and row.get('order') is not None and row['end'] >= row['order']), 'invalid collection range')
    if confirmed:
        require(plan.get('confirmed') is True, 'user-confirmed result required')
    return rows


def build(catalog, groups):
    items = normalize(catalog)
    rows = {x['gid']: dict(x, seriesId='item:' + str(x['gid']), series=x['title'] or x['titleJpn'] or str(x['gid']), category='main', branch='main', order=None, end=None, note='独立保留') for x in items}
    require(isinstance(groups, dict) and isinstance(groups.get('series'), list), 'groups needs a series list')
    assigned = set()
    for i, group in enumerate(groups['series'], 1):
        require(isinstance(group.get('name'), str) and group['name'].strip(), 'series name required')
        require(isinstance(group.get('members'), list) and group['members'], 'series members required')
        for member in group['members']:
            member = {'gid': member} if integer(member) else member
            require(isinstance(member, dict) and integer(member.get('gid')), 'invalid member')
            gid = member['gid']
            require(gid in rows and gid not in assigned, 'unknown or duplicate grouped GID')
            assigned.add(gid)
            rows[gid].update(seriesId='series:' + str(i), series=group['name'].strip(), category=member.get('category', 'main'), branch=member.get('branch', 'main'), order=member.get('order'), end=member.get('end'), note=member.get('note', group.get('note', '')))
    grouped = {}
    for row in rows.values():
        grouped.setdefault(row['seriesId'], []).append(row)
    ordered = []
    for values in sorted(grouped.values(), key=lambda rs: min(r['originalPosition'] for r in rs)):
        anchors = {}
        for row in values:
            key = (row['category'], row['branch'])
            anchors[key] = min(anchors.get(key, row['originalPosition']), row['originalPosition'])
        def key(row):
            require(row['order'] is None or number(row['order']), 'invalid chapter order')
            return (KINDS.index(row['category']), anchors[(row['category'], row['branch'])], row['order'] is None, row['order'] or 0, row['originalPosition'])
        ordered.extend(sorted(values, key=key))
    plan = dict(formatVersion=1, catalogHash=catalog_hash(items), confirmed=False, items=ordered, gidOrder=[r['gid'] for r in ordered])
    validate_plan(catalog, plan)
    return plan


def apply(db, catalog, plan, backup, output):
    validate_plan(catalog, plan, confirmed=True)
    require(Path(backup).resolve() != Path(output).resolve(), 'backup and output must differ')
    require(not Path(backup).exists() and not Path(output).exists(), 'refusing to overwrite database files')
    snapshot(db, backup)
    fresh = db_items(backup, writable=True)
    require(catalog_hash(fresh) == plan['catalogHash'], 'fresh library changed; regroup before writing')
    before = db_digest(backup, ignore_time=True)
    snapshot(backup, output)
    stamp = int(time.time() * 1000)
    with closing(sqlite3.connect(output)) as con, con:
        for i, gid in enumerate(plan['gidOrder']):
            require(con.execute('UPDATE DOWNLOADS SET TIME=? WHERE GID=?', (stamp-i*1000, gid)).rowcount == 1, 'GID update mismatch')
    with connect(output) as con:
        require(con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'SQLite integrity failed')
    require(db_digest(output, ignore_time=True) == before, 'non-TIME data or schema changed')
    require([x['gid'] for x in db_items(output)] == plan['gidOrder'], 'database order mismatch')
    return dict(status='passed', itemCount=len(fresh), onlyDownloadsTimeChanged=True, backup=str(backup), output=str(output))


def review_html(plan):
    esc = lambda x: html.escape(str(x or ''), quote=True)
    static = ''.join('<article><b>' + esc(r['title'] or r['titleJpn']) + '</b><p>' + esc(r['titleJpn']) + '</p><p>GID ' + str(r['gid']) + ' · ' + esc(r['series']) + '</p></article>' for r in plan['items'])
    data = json.dumps(plan, ensure_ascii=False, allow_nan=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    return r"""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>漫画库整理预览</title>
<style>body{font:16px system-ui;margin:24px;background:#f6f5f1;color:#252525}header{max-width:1100px;margin:auto}input,button,select{font:inherit;padding:8px;max-width:100%;box-sizing:border-box}button{cursor:pointer}nav{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}#groups{max-width:1100px;margin:auto}section{background:white;padding:16px;margin:16px 0;border-radius:12px}article{padding:12px;border-top:1px solid #ddd;overflow-wrap:anywhere}article p{margin:6px 0;color:#555}h2{font-size:18px}#message{min-height:24px;color:#164c7e}label{display:inline-block}article[hidden],section[hidden]{display:none}small{color:#666}.buttons{display:flex;gap:6px;flex-wrap:wrap}</style>
<header><h1>漫画库整理预览</h1><p id="count"></p><input id="search" placeholder="搜索题名、系列或 GID" type="search"><nav><button id="select-visible">选择显示条目</button><button id="clear">清空选择</button><input id="series-name" placeholder="目标系列名称"><button id="assign">所选归入此系列</button><button id="independent">所选独立保留</button></nav><nav><button id="undo">撤销</button><button id="draft">保存进度</button><label>恢复进度 <input id="import" type="file" accept=".json"></label></nav><p>可直接确认整个结果；无需逐本勾选。位置为空表示未知，手动上下移可以调整顺序。</p><label><input id="confirm" type="checkbox"> 我已检查并确认整个分类与顺序</label> <button id="export">导出确认结果</button><p id="message" role="status"></p></header>
<main id="groups">""" + static + '<script id="data" type="application/json">' + data + r"""</script><script>
'use strict';
const base=JSON.parse(document.querySelector('#data').textContent),clone=x=>JSON.parse(JSON.stringify(x)),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let rows=clone(base.items),selected=new Set(),history=[];
const $=id=>document.getElementById(id),say=x=>$('message').textContent=x;
function saveState(){history.push(clone(rows));$('confirm').checked=false;}
function render(){let groups=[];for(const r of rows){if(!groups.length||groups.at(-1).id!==r.seriesId)groups.push({id:r.seriesId,name:r.series,items:[]});groups.at(-1).items.push(r);}
$('groups').innerHTML=groups.map(g=>`<section><h2>${esc(g.name)} <small>${g.items.length} 本</small></h2>${g.items.map(r=>`<article data-gid="${r.gid}"><label><input type="checkbox" data-select="${r.gid}" ${selected.has(r.gid)?'checked':''}> <b>${esc(r.title||r.titleJpn)}</b></label><p>${esc(r.titleJpn)}</p><p>GID ${r.gid} · ${esc(r.category)} · ${esc(r.branch)} · 位置 ${r.order??'未知'}${r.end!=null?'–'+r.end:''}</p><p>${esc(r.note)}</p><div class="buttons"><button data-move="up" data-gid="${r.gid}">上移</button><button data-move="down" data-gid="${r.gid}">下移</button><button data-edit="${r.gid}">修改章号标注</button></div></article>`).join('')}</section>`).join('');
$('count').textContent=`${rows.length} 本 · ${new Set(rows.map(r=>r.seriesId)).size} 个系列/独立条目 · 已选 ${selected.size} 本`;$('undo').disabled=!history.length;filter();}
function filter(){let q=$('search').value.toLowerCase(),by=new Map(rows.map(r=>[r.gid,r]));for(const el of document.querySelectorAll('article[data-gid]')){const r=by.get(Number(el.dataset.gid));el.hidden=q&&!`${r.gid} ${r.title} ${r.titleJpn} ${r.series}`.toLowerCase().includes(q);}for(const el of document.querySelectorAll('section'))el.hidden=![...el.querySelectorAll('article')].some(a=>!a.hidden);}
$('search').oninput=filter;
$('groups').onchange=e=>{if(e.target.dataset.select){const g=Number(e.target.dataset.select);e.target.checked?selected.add(g):selected.delete(g);$('count').textContent=`${rows.length} 本 · ${new Set(rows.map(r=>r.seriesId)).size} 个系列/独立条目 · 已选 ${selected.size} 本`;}};
$('select-visible').onclick=()=>{document.querySelectorAll('article[data-gid]:not([hidden])').forEach(el=>selected.add(Number(el.dataset.gid)));render();};$('clear').onclick=()=>{selected.clear();render();};
$('assign').onclick=()=>{const name=$('series-name').value.trim();if(!name||!selected.size)return say('填写系列名称并选择条目。');saveState();let id=rows.find(r=>r.series===name)?.seriesId||'manual:'+Date.now();for(const r of rows)if(selected.has(r.gid)){r.seriesId=id;r.series=name;}const members=rows.filter(r=>r.seriesId===id),at=rows.findIndex(r=>r.seriesId===id),other=rows.filter(r=>r.seriesId!==id);other.splice(at,0,...members);rows=other;render();};
$('independent').onclick=()=>{if(!selected.size)return;saveState();for(const r of rows)if(selected.has(r.gid)){r.seriesId='item:'+r.gid;r.series=r.title||r.titleJpn||String(r.gid);}render();};
$('groups').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.move){const i=rows.findIndex(r=>r.gid===Number(b.dataset.gid)),j=i+(b.dataset.move==='up'?-1:1);if(j>=0&&j<rows.length){saveState();[rows[i],rows[j]]=[rows[j],rows[i]];render();}}else if(b.dataset.edit){const r=rows.find(r=>r.gid===Number(b.dataset.edit)),value=prompt('位置编号；留空表示未知',r.order??'');if(value===null)return;const n=value.trim()===''?null:Number(value);if(n!==null&&(!Number.isFinite(n)||n<0))return say('请输入非负编号或留空。');if(r.end!==null&&(n===null||n>r.end))return say('合集开始位置不能大于结束位置。');saveState();r.order=n;render();}};
$('undo').onclick=()=>{if(history.length){rows=history.pop();$('confirm').checked=false;render();}};
function payload(confirmed){return {...base,confirmed,items:clone(rows),gidOrder:rows.map(r=>r.gid)};}
function download(confirmed){if(confirmed&&!$('confirm').checked)return say('请先确认整个结果。');const blob=new Blob([JSON.stringify(payload(confirmed),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=confirmed?'confirmed.json':'draft.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);say('已导出；没有操作手机。');}
$('draft').onclick=()=>download(false);$('export').onclick=()=>download(true);
$('import').onchange=async e=>{try{const p=JSON.parse(await e.target.files[0].text()),by=new Map(base.items.map(r=>[r.gid,r]));if(p.formatVersion!==1||p.catalogHash!==base.catalogHash||!Array.isArray(p.items)||p.items.length!==rows.length||new Set(p.items.map(r=>r.gid)).size!==rows.length||JSON.stringify(p.gidOrder)!==JSON.stringify(p.items.map(r=>r.gid)))throw Error('进度与书库不匹配');const names=new Map();for(const r of p.items){const old=by.get(r.gid);if(!old||r.title!==old.title||r.titleJpn!==old.titleJpn||typeof r.seriesId!=='string'||!r.seriesId.trim()||typeof r.series!=='string'||!r.series.trim()||typeof r.branch!=='string'||!r.branch.trim()||!['main','extra','collection','remaster','other'].includes(r.category)||(r.order!==null&&(!Number.isFinite(r.order)||r.order<0))||(r.end!==null&&(!Number.isFinite(r.end)||r.order===null||r.end<r.order))||(names.has(r.seriesId)&&names.get(r.seriesId)!==r.series))throw Error('进度字段或原题不匹配');names.set(r.seriesId,r.series);}saveState();rows=clone(p.items);selected.clear();render();say('进度已恢复，请重新确认最终结果。');}catch(err){say(err.message);}e.target.value='';};render();
</script></main></html>"""


def main():
    p = argparse.ArgumentParser(description='EhViewer: catalog → groups → preview → confirmed database copy.')
    sub = p.add_subparsers(dest='command', required=True)
    c = sub.add_parser('catalog');src=c.add_mutually_exclusive_group(required=True);src.add_argument('--db', type=Path);src.add_argument('--json', type=Path);c.add_argument('--out', required=True, type=Path)
    b = sub.add_parser('build');b.add_argument('--catalog', required=True, type=Path);b.add_argument('--groups', required=True, type=Path);b.add_argument('--out', required=True, type=Path)
    a = sub.add_parser('apply');a.add_argument('--db', required=True, type=Path);a.add_argument('--catalog', required=True, type=Path);a.add_argument('--order', required=True, type=Path);a.add_argument('--out', required=True, type=Path)
    v = sub.add_parser('verify');v.add_argument('--db', required=True, type=Path);v.add_argument('--expected', required=True, type=Path)
    args = p.parse_args()
    if args.command == 'verify':
        with connect(args.db) as con:
            require(con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'SQLite integrity failed')
        require(db_digest(args.db) == db_digest(args.expected), 'database differs from verified sorting copy')
        print(json.dumps(dict(status='passed', databaseMatches=True)));return
    args.out.mkdir(parents=True, exist_ok=True)
    if args.command == 'catalog':
        if args.db:
            snapshot(args.db, args.out/'source.db');items=db_items(args.out/'source.db')
        else:
            items=normalize(read(args.json))
        write(args.out/'catalog.json',dict(items=items));print(json.dumps(dict(itemCount=len(items))));return
    catalog = read(args.catalog)
    if args.command == 'build':
        plan=build(catalog,read(args.groups));require(not (args.out/'review.html').exists(), 'preview already exists')
        write(args.out/'order.json',plan)
        with (args.out/'review.html').open('x',encoding='utf-8') as f:f.write(review_html(plan))
        print(json.dumps(dict(itemCount=len(plan['items']),seriesCount=len({r['seriesId'] for r in plan['items']}))));return
    require(not (args.out/'report.json').exists(), 'report already exists')
    report=apply(args.db,catalog,read(args.order),args.out/'backup.db',args.out/'sorted.db')
    write(args.out/'report.json',report);print(json.dumps(report))


if __name__ == '__main__':
    main()
